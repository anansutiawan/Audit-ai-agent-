# Smart Contract AI Audit Agent

Audit otomatis smart contract:
- Ambil kode dari Infura (alamat Ethereum)
- Analisa dengan Slither
- Simpulkan dengan AI (OpenAI/Groq)

## Cara Pakai
```bash
pip install -r requirements.txt
python main.py
```
